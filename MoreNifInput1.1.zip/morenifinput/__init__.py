bl_info = {
    "name": "More Nif Input",
    "author": "FrozenTumbleweed",
    "version": (1, 1, 0),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar > MoreNifInput",
    "description": "Batch-import NIF files with grouping modes, cleanup options, error placeholders, automatic spacing-based scaling, library size detection, same-name/contains mesh filters and oversized-mesh separation.",
    "category": "Import-Export",
}

import math
import os
import re

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup, UIList


def _library_root(settings):
    if not settings.library_path:
        return ""
    return os.path.abspath(bpy.path.abspath(settings.library_path))


def _find_meshes_dir(mod_dir):
    for candidate in os.listdir(mod_dir):
        candidate_path = os.path.join(mod_dir, candidate)
        if os.path.isdir(candidate_path) and candidate.lower() == "meshes":
            return candidate_path
    return None


def _prefix_of_filename(filename):
    stem = os.path.splitext(filename)[0]
    match = re.match(r"^(.+?)_", stem)
    return (match.group(1) if match else stem).lower()


def _deduplicate_files(files):
    kept = []
    seen_prefixes = set()
    for file_path in files:
        prefix = _prefix_of_filename(os.path.basename(file_path))
        if prefix in seen_prefixes:
            continue
        seen_prefixes.add(prefix)
        kept.append(file_path)
    return kept


def _nif_files_under(directory):
    files = []
    for current_root, _dirs, filenames in os.walk(directory):
        for filename in filenames:
            if filename.lower().endswith(".nif"):
                files.append(os.path.join(current_root, filename))
    files.sort(key=lambda path: path.lower())
    return files


def _mod_level_groups(root):
    groups = []
    for mod_name in sorted(os.listdir(root)):
        mod_dir = os.path.join(root, mod_name)
        if not os.path.isdir(mod_dir):
            continue
        meshes_dir = _find_meshes_dir(mod_dir)
        if meshes_dir is None:
            continue

        kept_files = _deduplicate_files(_nif_files_under(meshes_dir))
        if kept_files:
            groups.append(
                {
                    "name": mod_name,
                    "mod_name": mod_name,
                    "relative_path": "",
                    "files": kept_files,
                }
            )
    return groups


def _minimum_layer_groups(root):
    groups = []
    for mod_name in sorted(os.listdir(root)):
        mod_dir = os.path.join(root, mod_name)
        if not os.path.isdir(mod_dir):
            continue
        meshes_dir = _find_meshes_dir(mod_dir)
        if meshes_dir is None:
            continue

        direct_files = sorted(
            os.path.join(meshes_dir, filename)
            for filename in os.listdir(meshes_dir)
            if filename.lower().endswith(".nif")
            and os.path.isfile(os.path.join(meshes_dir, filename))
        )
        kept_direct = _deduplicate_files(direct_files)
        if kept_direct:
            groups.append(
                {
                    "name": mod_name,
                    "mod_name": mod_name,
                    "relative_path": "",
                    "files": kept_direct,
                }
            )

        for current_root, dirs, filenames in os.walk(meshes_dir):
            dirs.sort(key=lambda name: name.lower())
            if os.path.abspath(current_root) == os.path.abspath(meshes_dir):
                continue

            nif_files = sorted(
                os.path.join(current_root, filename)
                for filename in filenames
                if filename.lower().endswith(".nif")
            )
            kept_files = _deduplicate_files(nif_files)
            if not kept_files:
                continue

            relative_dir = os.path.relpath(current_root, meshes_dir)
            relative_parts = [part for part in relative_dir.split(os.sep) if part]
            relative_path = "/".join(relative_parts)
            groups.append(
                {
                    "name": f"{mod_name}/{relative_path}",
                    "mod_name": mod_name,
                    "relative_path": relative_path,
                    "files": kept_files,
                }
            )
    return groups


def scan_library(root, mode):
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        return []
    if mode == "MOD_LEVEL":
        return _mod_level_groups(root)
    return _minimum_layer_groups(root)


def populate_settings(settings, groups):
    settings.groups.clear()
    for group in groups:
        group_item = settings.groups.add()
        group_item.name = group["name"]
        group_item.mod_name = group["mod_name"]
        group_item.relative_path = group["relative_path"]
        for file_path in group["files"]:
            file_item = group_item.files.add()
            file_item.file_path = file_path
            file_item.display_name = os.path.basename(file_path)


GIGABYTE = 1024 ** 3


def _groups_total_size_gb(groups):
    """本次会导入的 NIF（检测后各组去重留下的文件）总大小，单位 GB（1GB = 1024^3 字节）。"""
    total_bytes = 0
    for group in groups:
        for file_path in group["files"]:
            try:
                total_bytes += os.path.getsize(file_path)
            except OSError:
                continue
    return total_bytes / GIGABYTE


def _format_size_gb(size_gb):
    return f"{size_gb:.2f}G"


def _suggest_grid(group_count):
    if group_count <= 0:
        return 1, 1
    rows = max(1, math.ceil(math.sqrt(group_count)))
    columns = max(1, math.ceil(group_count / rows))
    return rows, columns


def _unique_child_name(parent, preferred):
    if parent.children.find(preferred) == -1:
        return preferred
    suffix = 1
    while parent.children.find(f"{preferred}.{suffix:03d}") != -1:
        suffix += 1
    return f"{preferred}.{suffix:03d}"


def _ensure_child_collection(parent, preferred):
    if parent.children.find(preferred) != -1:
        return parent.children[preferred]
    child = bpy.data.collections.new(_unique_child_name(parent, preferred))
    parent.children.link(child)
    return child


def _ensure_group_collection(base, mod_name, relative_path):
    mod_collection = _ensure_child_collection(base, mod_name)
    current = mod_collection
    if relative_path:
        for component in relative_path.split("/"):
            if not component:
                continue
            current = _ensure_child_collection(current, component)
    return current


def _handle_failed_group(base, group, center, settings, placeholder_index):
    mod_collection = _ensure_child_collection(base, group.mod_name)
    _clear_collection_contents(mod_collection)
    bpy.context.view_layer.update()

    if not _set_active_layer_collection(mod_collection.name):
        return

    bpy.ops.mesh.primitive_cube_add(
        size=settings.spacing * 0.6,
        location=center,
    )
    placeholder = bpy.context.object
    if placeholder is not None:
        placeholder.name = f"报错mod占位符{placeholder_index:02d}"


def _set_active_layer_collection(name):
    view_layer = bpy.context.view_layer

    def visit(layer_collection):
        if layer_collection.name == name:
            view_layer.active_layer_collection = layer_collection
            return True
        for child in layer_collection.children:
            if visit(child):
                return True
        return False

    return visit(view_layer.layer_collection)


def _object_in_view_layer(obj):
    return bpy.context.view_layer.objects.get(obj.name) is not None


def _remove_object(obj):
    if obj.name in bpy.data.objects:
        bpy.data.objects.remove(obj, do_unlink=True)


def _clear_collection_contents(collection):
    for child in list(collection.children):
        _clear_collection_contents(child)
        if child.name in bpy.data.collections:
            bpy.data.collections.remove(child)

    for obj in list(collection.objects):
        _remove_object(obj)


def _ensure_base_collection():
    base = bpy.data.collections.get("Collection")
    if base is None:
        base = bpy.data.collections.new("Collection")
        bpy.context.scene.collection.children.link(base)
    return base


def _transform_group_roots(new_objects, center, spacing):
    roots = [
        obj
        for obj in new_objects
        if (obj.parent is None or obj.parent not in new_objects)
        and _object_in_view_layer(obj)
    ]
    if not roots:
        return

    mesh_objects = [obj for obj in new_objects if obj.type == "MESH"]
    dimensions = []
    for obj in mesh_objects:
        dimensions.append(obj.dimensions.x)
        dimensions.append(obj.dimensions.y)
    size = max(dimensions) if dimensions else 0.0
    if size <= 0:
        return

    ratio = spacing / size

    bpy.ops.object.select_all(action="DESELECT")
    for obj in roots:
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        obj.location = center
        obj.scale = (
            obj.scale[0] * ratio,
            obj.scale[1] * ratio,
            obj.scale[2] * ratio,
        )


def _english_part(name):
    return "".join(ch for ch in name if ch.isascii() and ch.isalpha()).lower()


# 默认屏蔽词表版本：1.0 及更早为 1，1.1 起为 2（同名表 + 包含表）
FILTER_DEFAULTS_VERSION = 2


def _default_filter_terms():
    """同名屏蔽词默认表：完整名称匹配。"""
    return ["feet", "hand", "collision", "Colliders", "3BBB", "unbp"]


def _default_contains_filter_terms():
    """包含屏蔽词默认表：名称中包含即匹配。"""
    return ["3BA"]


def _ensure_default_filter_terms(settings):
    """初始化/升级两张默认屏蔽词表（按默认表版本号，只执行一次）。"""
    if settings.filters_defaults_version >= FILTER_DEFAULTS_VERSION:
        return

    settings.filter_terms.clear()
    for term in _default_filter_terms():
        item = settings.filter_terms.add()
        item.name = term

    settings.contains_filter_terms.clear()
    for term in _default_contains_filter_terms():
        item = settings.contains_filter_terms.add()
        item.name = term

    settings.filters_defaults_version = FILTER_DEFAULTS_VERSION


# ---------------------------------------------------------------------------
# debug 修复：Blender 5.x 不允许在界面绘制（Panel.draw）等受限上下文中写入 ID
# 数据，否则会抛出：
#   AttributeError: Writing to ID classes in this context is not allowed:
#   Scene, Scene data-block, error setting MoreNifInputSettings.<UNKNOWN>
# 因此 draw() 只做读取并申请延迟初始化，真正的写入交给定时器在绘制之外执行。
# ---------------------------------------------------------------------------
_filter_setup_pending = False


def _run_deferred_filter_setup():
    global _filter_setup_pending
    _filter_setup_pending = False
    for scene in bpy.data.scenes:
        try:
            scene_settings = getattr(scene, "morenifinput", None)
            if scene_settings is None:
                continue
            _ensure_default_filter_terms(scene_settings)
        except Exception:
            continue
    return None


def _request_deferred_filter_setup():
    """申请在绘制上下文之外初始化默认屏蔽词（可在 draw() 中安全调用）。"""
    global _filter_setup_pending
    if _filter_setup_pending:
        return
    try:
        if bpy.app.timers.is_registered(_run_deferred_filter_setup):
            return
    except Exception:
        pass
    _filter_setup_pending = True
    try:
        bpy.app.timers.register(_run_deferred_filter_setup, first_interval=0.0)
    except Exception:
        _filter_setup_pending = False


def _name_matches_filter(obj_name, settings):
    lowered_name = obj_name.lower()
    for item in settings.filter_terms:
        if item.name and item.name.lower() == lowered_name:
            return True
    for item in settings.contains_filter_terms:
        term = item.name.lower()
        if term and term in lowered_name:
            return True
    return False


def _active_filter_list(settings):
    """返回当前屏蔽词表及其选中项索引的属性名。"""
    if settings.filter_mode == "CONTAINS":
        return settings.contains_filter_terms, "active_contains_filter_index"
    return settings.filter_terms, "active_filter_index"


def _deduplicate_meshes_by_prefix_and_vertex_count(mesh_objects):
    sorted_meshes = sorted(mesh_objects, key=lambda obj: obj.name)
    index = 0
    while index < len(sorted_meshes):
        group_key = _english_part(sorted_meshes[index].name)
        group = [sorted_meshes[index]]
        cursor = index + 1
        while cursor < len(sorted_meshes):
            candidate = sorted_meshes[cursor]
            if _english_part(candidate.name) != group_key:
                break
            group.append(candidate)
            cursor += 1

        if len(group) > 1:
            vertex_counts = [len(obj.data.vertices) for obj in group]
            if len(set(vertex_counts)) == 1:
                for obj in group[1:]:
                    if obj.name in bpy.data.objects:
                        _remove_object(obj)

        index = cursor


def _meshes_with_numbered_suffixes(mesh_objects):
    suffixes = [f".{number:03d}" for number in range(1, 10)]
    return [
        obj
        for obj in mesh_objects
        if any(suffix in obj.name for suffix in suffixes)
    ]


def _delete_all_camera_objects():
    for obj in [obj for obj in bpy.data.objects if obj.type == "CAMERA"]:
        bpy.data.objects.remove(obj, do_unlink=True)


def _meshes_exceeding_spacing(settings):
    """检测所有网格体，返回 (XY 任一项大于间距的网格体, 这些网格体 XY 尺寸的最大值)。"""
    spacing = settings.spacing
    oversized_meshes = []
    max_xy = 0.0
    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        size_x = obj.dimensions.x
        size_y = obj.dimensions.y
        if size_x <= spacing and size_y <= spacing:
            continue
        oversized_meshes.append(obj)
        max_xy = max(max_xy, size_x, size_y)
    return oversized_meshes, max_xy


def _move_meshes_negative_x(mesh_objects, distance):
    """把给定网格体一起向 -X 方向移动 distance。"""
    if not mesh_objects or distance <= 0.0:
        return

    movable_objects = [obj for obj in mesh_objects if _object_in_view_layer(obj)]
    if movable_objects:
        bpy.ops.object.select_all(action="DESELECT")
        for obj in movable_objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = movable_objects[0]
        if bpy.ops.transform.translate.poll():
            bpy.ops.transform.translate(value=(-distance, 0.0, 0.0))
            return

    for obj in mesh_objects:
        obj.location.x -= distance


def _clear_all_animation():
    for action in list(bpy.data.actions):
        bpy.data.actions.remove(action)

    for obj in bpy.data.objects:
        if obj.animation_data is None:
            continue
        for track in list(obj.animation_data.nla_tracks):
            obj.animation_data.nla_tracks.remove(track)
        obj.animation_data_clear()

    for scene in bpy.data.scenes:
        if scene.animation_data is not None:
            scene.animation_data_clear()


def _show_error_popup(context, failed_mods):
    if not failed_mods:
        return
    if bpy.app.background:
        return

    message = "报错模组：" + "、".join(failed_mods)
    try:
        def draw_popup(self, context):
            self.layout.label(text=message)

        context.window_manager.popup_menu(draw_popup, title="导入完成但有报错", icon="ERROR")
    except Exception:
        pass


def _cleanup_group(group_object_names, settings):
    def remaining():
        return [
            bpy.data.objects[name]
            for name in group_object_names
            if name in bpy.data.objects
        ]

    invalid_objects = [obj for obj in remaining() if not _object_in_view_layer(obj)]
    for obj in invalid_objects:
        _remove_object(obj)
    had_invalid_objects = bool(invalid_objects)

    if settings.remove_armature_empty:
        for obj in [
            obj
            for obj in remaining()
            if obj.type == "MESH" and _object_in_view_layer(obj)
        ]:
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj

            if bpy.ops.object.transform_apply.poll():
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            if obj.parent is not None and bpy.ops.object.parent_clear.poll():
                bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
            obj.modifiers.clear()

        for obj in [obj for obj in remaining() if obj.type in {"EMPTY", "ARMATURE"}]:
            _remove_object(obj)

    _delete_all_camera_objects()

    if settings.remove_collision_meshes:
        for obj in [obj for obj in remaining() if obj.type == "MESH"]:
            if len(obj.data.materials) == 0:
                _remove_object(obj)

    for obj in [
        obj
        for obj in remaining()
        if obj.type == "MESH" and _name_matches_filter(obj.name, settings)
    ]:
        _remove_object(obj)

    _deduplicate_meshes_by_prefix_and_vertex_count(
        [obj for obj in remaining() if obj.type == "MESH"]
    )

    bpy.ops.file.pack_all()
    bpy.ops.outliner.orphans_purge(
        do_local_ids=True,
        do_linked_ids=True,
        do_recursive=True,
    )

    return had_invalid_objects


class MoreNifInputFileItem(PropertyGroup):
    file_path: StringProperty()
    display_name: StringProperty()


class MoreNifInputFilterItem(PropertyGroup):
    name: StringProperty()


class MoreNifInputGroupItem(PropertyGroup):
    name: StringProperty()
    mod_name: StringProperty()
    relative_path: StringProperty()
    files: CollectionProperty(type=MoreNifInputFileItem)


class MoreNifInputSettings(PropertyGroup):
    library_path: StringProperty(
        name="库地址",
        description="NIF 文件库根目录（main）",
        subtype="DIR_PATH",
    )
    mode: EnumProperty(
        name="输出模式",
        items=[
            ("MOD_LEVEL", "按 mod 文件层输出", "每个 mod 的 meshes 内全部 NIF 作为一组"),
            ("MIN_LAYER", "最小文件层输出", "按 meshes 下每个直接包含 NIF 的目录分别成组"),
        ],
        default="MIN_LAYER",
    )
    detected_group_count: IntProperty(
        name="检测到的组数",
        default=0,
        min=0,
    )
    detected_total_size_gb: FloatProperty(
        name="检测到的NIF总大小(GB)",
        description="检测到的本次会导入的 NIF 文件总大小（GB）",
        default=0.0,
        min=0.0,
        precision=3,
    )
    filter_terms: CollectionProperty(type=MoreNifInputFilterItem)
    contains_filter_terms: CollectionProperty(type=MoreNifInputFilterItem)
    filter_mode: EnumProperty(
        name="屏蔽词类型",
        description="切换要编辑的屏蔽词表",
        items=[
            ("SAME", "同名", "网格体名称与屏蔽词完全相同才屏蔽（不区分大小写）"),
            ("CONTAINS", "包含", "网格体名称中包含屏蔽词即屏蔽（不区分大小写）"),
        ],
        default="SAME",
    )
    active_filter_index: IntProperty()
    active_contains_filter_index: IntProperty()
    filter_term_input: StringProperty(
        name="新增屏蔽词",
        description="输入要添加的网格名称屏蔽词",
        default="",
    )
    filters_defaults_version: IntProperty(
        name="屏蔽词默认表版本",
        default=0,
        min=0,
    )
    remove_armature_empty: BoolProperty(
        name="移除骨骼和空物体的影响",
        description="应用旋转+缩放，清除父级和修改器，并删除空物体与骨架",
        default=True,
    )
    remove_collision_meshes: BoolProperty(
        name="移除碰撞网格",
        description="删除不含材质的网格体",
        default=True,
    )
    split_secondary_parts: BoolProperty(
        name="拆分次级部件",
        description="将名称含 .001-.009 的网格体向 -Y 方向拆分移动",
        default=True,
    )
    rows: IntProperty(
        name="行数",
        description="导入网格的行数",
        default=2,
        min=1,
    )
    columns: IntProperty(
        name="列数",
        description="导入网格的列数",
        default=2,
        min=1,
    )
    spacing: FloatProperty(
        name="间距",
        description="相邻组之间的间距（米）",
        default=1.0,
        min=0.000001,
        subtype="DISTANCE",
    )
    groups: CollectionProperty(type=MoreNifInputGroupItem)


class MORENIFINPUT_UL_filter_terms(UIList):
    bl_idname = "MORENIFINPUT_UL_filter_terms"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name)


class MoreNifInputOT_add_filter_term(Operator):
    bl_idname = "morenifinput.add_filter_term"
    bl_label = "添加屏蔽词"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.morenifinput
        term = settings.filter_term_input.strip()
        if not term:
            self.report({"ERROR"}, "请输入屏蔽词")
            return {"CANCELLED"}

        terms, index_prop = _active_filter_list(settings)
        if any(item.name == term for item in terms):
            self.report({"WARNING"}, "该屏蔽词已存在")
        else:
            item = terms.add()
            item.name = term
            setattr(settings, index_prop, len(terms) - 1)

        settings.filter_term_input = ""
        return {"FINISHED"}


class MoreNifInputOT_remove_filter_term(Operator):
    bl_idname = "morenifinput.remove_filter_term"
    bl_label = "删除屏蔽词"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.morenifinput
        terms, index_prop = _active_filter_list(settings)
        index = getattr(settings, index_prop)
        if 0 <= index < len(terms):
            terms.remove(index)
            setattr(settings, index_prop, min(index, len(terms) - 1))
        return {"FINISHED"}


class MoreNifInputOT_detect_count(Operator):
    bl_idname = "morenifinput.detect_count"
    bl_label = "检测数量与大小"
    bl_description = "检测当前模式下 NIF 组数与整个库路径的 NIF 总大小，并填入建议的行列数"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.morenifinput
        _ensure_default_filter_terms(settings)
        root = _library_root(settings)

        if not root:
            self.report({"ERROR"}, "请先填写库地址")
            return {"CANCELLED"}
        if not os.path.isdir(root):
            self.report({"ERROR"}, "库地址无效，请检查路径")
            return {"CANCELLED"}

        groups = scan_library(root, settings.mode)
        settings.detected_group_count = len(groups)
        populate_settings(settings, groups)
        settings.detected_total_size_gb = _groups_total_size_gb(groups)

        if not groups:
            self.report({"ERROR"}, "库中没有找到 NIF 文件")
            return {"CANCELLED"}

        rows, columns = _suggest_grid(len(groups))
        settings.rows = rows
        settings.columns = columns
        self.report(
            {"INFO"},
            "检测到 {} 组（NIF 总大小 {}），建议 {} 行 x {} 列".format(
                len(groups),
                _format_size_gb(settings.detected_total_size_gb),
                rows,
                columns,
            ),
        )
        return {"FINISHED"}


class MoreNifInputOT_import(Operator):
    bl_idname = "morenifinput.import_groups"
    bl_label = "开始导入"
    bl_description = "按当前模式和参数批量导入所有 NIF 组"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.morenifinput
        _ensure_default_filter_terms(settings)
        root = _library_root(settings)

        if not root:
            self.report({"ERROR"}, "请先填写库地址")
            return {"CANCELLED"}
        if not os.path.isdir(root):
            self.report({"ERROR"}, "库地址无效，请检查路径")
            return {"CANCELLED"}

        groups = scan_library(root, settings.mode)
        if not groups:
            self.report({"ERROR"}, "库中没有找到 NIF 文件")
            return {"CANCELLED"}
        populate_settings(settings, groups)
        settings.detected_group_count = len(groups)

        if settings.rows < 1 or settings.columns < 1:
            self.report({"ERROR"}, "行数和列数必须为正整数")
            return {"CANCELLED"}
        if settings.spacing <= 0:
            self.report({"ERROR"}, "间距必须大于 0")
            return {"CANCELLED"}
        if settings.rows * settings.columns < len(groups):
            self.report(
                {"ERROR"},
                f"行列之积({settings.rows} x {settings.columns})小于 NIF 组数({len(groups)})",
            )
            return {"CANCELLED"}

        if not hasattr(bpy.ops.import_scene, "pynifly"):
            self.report({"ERROR"}, "请先安装并启用 io_scene_nifly 插件")
            return {"CANCELLED"}

        base = _ensure_base_collection()
        columns = settings.columns
        spacing = settings.spacing
        failed_mods = []
        placeholder_index = 1

        total_groups = len(settings.groups)

        for index, group in enumerate(settings.groups):
            row = index // columns
            column = index % columns
            center = (
                column * spacing,
                (settings.rows - row) * spacing,
                0.0,
            )

            try:
                collection = _ensure_group_collection(
                    base,
                    group.mod_name,
                    group.relative_path,
                )
                bpy.context.view_layer.update()

                if not _set_active_layer_collection(collection.name):
                    raise RuntimeError(f"无法激活集合：{collection.name}")

                before = set(bpy.data.objects)
                for file_item in group.files:
                    result = bpy.ops.import_scene.pynifly(filepath=file_item.file_path)
                    if result != {"FINISHED"}:
                        raise RuntimeError(f"导入失败：{file_item.file_path}")
                after = set(bpy.data.objects)

                new_objects = [obj for obj in (after - before)]
                new_object_names = [obj.name for obj in new_objects]
                _transform_group_roots(new_objects, center, spacing)
                had_invalid_objects = _cleanup_group(new_object_names, settings)
                if had_invalid_objects:
                    raise RuntimeError("导入产生了不存在于当前视图层的数据")
            except Exception as exc:
                failed_mods.append(group.mod_name)
                print(f"GROUP_ERROR mod={group.mod_name} group={group.name} error={exc}")
                _handle_failed_group(
                    base,
                    group,
                    center,
                    settings,
                    placeholder_index,
                )
                placeholder_index += 1
        if settings.split_secondary_parts:
            numbered_meshes = [
                obj
                for obj in _meshes_with_numbered_suffixes(
                    [obj for obj in bpy.data.objects if obj.type == "MESH"]
                )
                if _object_in_view_layer(obj)
            ]
            if numbered_meshes:
                bpy.ops.object.select_all(action="DESELECT")
                for obj in numbered_meshes:
                    obj.select_set(True)
                bpy.context.view_layer.objects.active = numbered_meshes[0]

                distance = (settings.rows + 1) * settings.spacing
                if bpy.ops.transform.translate.poll():
                    bpy.ops.transform.translate(value=(0.0, -distance, 0.0))
                else:
                    for obj in numbered_meshes:
                        obj.location.y -= distance

        _clear_all_animation()

        # 最后一步（始终启用）：把 XY 尺寸超过间距的网格体一起沿 -X 移开
        oversized_meshes, max_oversized_xy = _meshes_exceeding_spacing(settings)
        _move_meshes_negative_x(oversized_meshes, max_oversized_xy)

        if failed_mods:
            _show_error_popup(context, failed_mods)
            self.report({"WARNING"}, "报错模组：" + "、".join(failed_mods))
        else:
            self.report({"INFO"}, "NIF 批量导入完成")

        return {"FINISHED"}


class MoreNifInputPT_panel(Panel):
    bl_label = "More Nif Input"
    bl_idname = "MORENIFINPUT_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "NifInput"

    def draw(self, context):
        settings = context.scene.morenifinput
        if settings.filters_defaults_version < FILTER_DEFAULTS_VERSION:
            # draw() 是受限上下文：这里只能申请延迟初始化，不能直接写入数据
            _request_deferred_filter_setup()
        layout = self.layout

        layout.label(text="导入准备")
        layout.prop(settings, "library_path")
        layout.prop(settings, "mode", expand=True)

        row = layout.row(align=True)
        row.operator("morenifinput.detect_count", text="检测数量与大小")
        row.label(
            text="{}({})".format(
                settings.detected_group_count,
                _format_size_gb(settings.detected_total_size_gb),
            )
        )

        layout.separator()
        layout.label(text="导入设置")
        layout.prop(settings, "remove_armature_empty")
        layout.prop(settings, "remove_collision_meshes")
        layout.prop(settings, "split_secondary_parts")

        layout.label(text="筛除带有以下名字的网格")
        layout.prop(settings, "filter_mode", expand=True)
        if settings.filter_mode == "CONTAINS":
            layout.template_list(
                "MORENIFINPUT_UL_filter_terms",
                "",
                settings,
                "contains_filter_terms",
                settings,
                "active_contains_filter_index",
                rows=4,
            )
        else:
            layout.template_list(
                "MORENIFINPUT_UL_filter_terms",
                "",
                settings,
                "filter_terms",
                settings,
                "active_filter_index",
                rows=4,
            )
        row = layout.row(align=True)
        row.prop(settings, "filter_term_input", text="")
        row.operator("morenifinput.add_filter_term", text="", icon="ADD")
        row.operator("morenifinput.remove_filter_term", text="", icon="REMOVE")

        box = layout.box()
        box.label(text="网格布局")
        box.prop(settings, "rows")
        box.prop(settings, "columns")
        box.prop(settings, "spacing")

        layout.operator("morenifinput.import_groups", text="开始导入")


classes = (
    MoreNifInputFileItem,
    MoreNifInputFilterItem,
    MoreNifInputGroupItem,
    MoreNifInputSettings,
    MORENIFINPUT_UL_filter_terms,
    MoreNifInputOT_add_filter_term,
    MoreNifInputOT_remove_filter_term,
    MoreNifInputOT_detect_count,
    MoreNifInputOT_import,
    MoreNifInputPT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.morenifinput = PointerProperty(type=MoreNifInputSettings)
    # 插件启用时不在 register() 内直接写场景数据，改由定时器完成
    _request_deferred_filter_setup()


def unregister():
    global _filter_setup_pending
    try:
        bpy.app.timers.unregister(_run_deferred_filter_setup)
    except Exception:
        pass
    _filter_setup_pending = False
    if hasattr(bpy.types.Scene, "morenifinput"):
        del bpy.types.Scene.morenifinput
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
